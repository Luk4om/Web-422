document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("regisForm");
    const resultDiv = document.getElementById("result");

    form.addEventListener("submit", (e) => {
        e.preventDefault();
        const name = form.elements["name"].value;
        const gender = form.elements["gender"].value;
        const interest = form.elements["interest"].value;
        const country = form.elements["country"].value;

        resultDiv.innerHTML = `<p>Name : ${name}</p> <p>Gender : ${gender}</p>`;
        resultDiv.innerHTML = `<p>Interest : ${interest}</p> <p>Country : ${country}</p>`;
    });
});